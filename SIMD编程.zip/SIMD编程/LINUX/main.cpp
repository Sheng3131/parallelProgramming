#include "utils.h"
#include <string>
#include <iostream>

// 函数声明
void serialGaussianElimination(Matrix& A, std::vector<float>& b);
void neonGaussianElimination(Matrix& A, std::vector<float>& b);

// 测试函数
void testAlgorithm(const std::string& name, 
                  void (*algorithm)(Matrix&, std::vector<float>&),
                  const Matrix& A_orig, const std::vector<float>& b_orig) {
    // ... [代码与之前相同] ...
}

int main(int argc, char* argv[]) {
    // ... [代码与之前相同] ...
    
    // 测试各算法
    testAlgorithm("串行算法", serialGaussianElimination, A_orig, b_orig);
    testAlgorithm("NEON向量化算法", neonGaussianElimination, A_orig, b_orig);
    
    return 0;
}
